USE Formula1DB
GO
DELETE Driver;
DELETE Team;
DELETE Event;
DELETE Circuit;

DBCC CHECKIDENT ('Team', RESEED, 0);
DBCC CHECKIDENT ('Circuit', RESEED, 0);
DBCC CHECKIDENT ('Event', RESEED, 0);

INSERT Team(TeamName, TeamNation, FoundingYear)
VALUES
    ('Scuderia Ferrari', 'Italy', 1929),
    ('Mercedes-AMG Petronas', 'Germany', 1954)

INSERT Team(TeamName, TeamNation)
VALUES ('Red Bull Racing Honda', 'Switzerland')

INSERT Driver(DriverID, DriverName, DateOfBirth, Nationality, TeamID)
VALUES
    (1, 'Lewis Hamilton', '1985-01-12', 'British', 2),
    (2, 'Valtteri Bottas', '1989-08-28', 'Swedish', 2),
    (3, 'Charles Leclerc', '1997-10-16', null, 1),
    (4, 'Sebastian Vettel', '1987-07-03', 'German', 1)
    --(5, 'Carlos Sainz', '1994-09-1', 'Spanish', 4) --Invalid team, violates foreign key constraint

INSERT Circuit(Type, Location, Length)
VALUES
    ('Race Circuit', 'Algarve International Circuit Portugal', 4.653),
    ('Road Circuit', 'AVUS Germany', 8.300),
    ('Race Circuit', 'Autodromo Internazionale Enzo e Dino Ferrari Italy', 4.909),
    ('Street Circuit', 'Adelaide Street Circuit Australia', 3.780),
    ('Race Circuit', 'Autodromo Nazionale Monza, Italy', 5.793),
    ('Race Circuit', 'Bahrain International Circuit', 5.412),
    ('Street Circuit', 'Marina Bay Street Circuit Singapore', 5.063),
    ('Race Circuit', 'Circuit de Barcelona-Catalunya', 4.655),
    ('Road Circuit', 'Circuit Bremgarten Switzerland', 7.208)


INSERT Event(EventDate, CircuitID)
VALUES
    ('2020-08-07', 1),
    ('2020-09-06', 1),
    ('2021-04-03', 2),
    (null, 1)
    --('2021-09-12', 12) - invalid circuit id (non existent) - violates foreign key constraint

INSERT Engine(Manufacturer, Power, Capacity)
VALUES
    ('Ferrari', 980, 1.6),
    ('Honda', 960, 1.5),
    ('Renault', 976, 1.58),
    ('Mercedes', 1000, 1.6)

ALTER TABLE Tires
ADD Compound varchar(50),
    DrivingConditions varchar(50),
    Grip smallint,
    Durability smallint

ALTER TABLE Car
ADD CarName varchar(50)

ALTER TABLE Tires
ADD Color varchar(50)

INSERT Tires(Compound, DrivingConditions, Grip, Durability, Color)
VALUES
    ('Hard', 'Dry', 5, 1, 'White'),
    ('Hard', 'Dry', 4, 2, 'White'),
    ('Hard', 'Dry', 3, 3, 'White'),
    ('Medium', 'Dry', 4, 2, 'Yellow'),
    ('Medium', 'Dry', 3, 3, 'Yellow'),
    ('Soft', 'Dry', 3, 3, 'Red'),
    ('Soft', 'Dry', 2, 4, 'Red'),
    ('Soft', 'Dry', 1, 5, 'Red'),
    ('Intermediate', 'Wet - light standing water', null, null, 'Green'),
    ('Wet', 'Wet - heavy standing water', null, null, 'Blue')

INSERT Car(CarNumber, DriverID, Cost, TireID, EngineID, CarName)
VALUES
    (1, 1, 12000000, 8, 4, 'Mercedes-AMG F1 W11 EQ Performance'),
    (2, 2, 12000000, 7, 4, 'Mercedes-AMG F1 W11 EQ Performance'),
    (3, 3, 11549000, 5, 1, 'Ferrari SF1000'),
    (4, 4, 11580000, 1, 1, 'Ferrari SF1000')

INSERT Sponsor(sponsorname, sponsorbudget)
VALUES
    ('Petronas', 50000000),
    ('INEOS', 3000000),
    ('Epson', 5000000),
    ('Tommy Hilfiger', 10000000),
    ('Pirelli', 20000000),
    ('Puma', 5000000),
    ('Ray Ban', 8000000),
    ('Kaspersky', 1000000)

INSERT Sponsor_Team(SponsorID, TeamID, SponsorshipValue)
VALUES
    (1, 2, 50000000),
    (2, 2, 3000000),
    (3, 2, 5000000),
    (4, 2, 10000000),
    (5, 2, 10000000),
    (5, 1, 8000000),
    (5, 3, 2000000),
    (6, 1, 2000000),
    (6, 2, 2000000),
    (6, 3, 1000000),
    (7, 1, 8000000),
    (8, 1, 500000),
    (8, 3, 500000)

INSERT Team_Event(TeamID, EventID)
VALUES
    (1, 1),
    (2, 1),
    (3, 1),
    (1, 2),
    (2, 2)

UPDATE Driver
SET DateOfBirth = '1985-01-07'
WHERE DriverName = 'Lewis Hamilton'

UPDATE Driver
SET Nationality = N'Monégasque'
WHERE DriverName = 'Charles Leclerc'

UPDATE Team
SET FoundingYear = 2005
WHERE TeamName = 'Red Bull Racing Honda'

UPDATE Circuit
SET Length = Length + 1
WHERE Type = 'Race Circuit'

DELETE
from Event
WHERE YEAR(EventDate) > 2020 AND MONTH(EventDate) >= 4

DELETE
from Event
WHERE EventDate is NULL
