import socket 
import threading
import struct

socketsArray = []
clientsList = []
mylock = threading.Lock()
e = threading.Event()
e.clear()
threads = []
client_count = 0


def tcp_send_string(sock, string):
    sock.send(string.encode('ascii'))


def tcp_send_int(sock, number):
    number = struct.pack('!i', number)
    sock.send(number)


def worker(cs):
    global mylock, client_count, e, socketsArray, clientsList
    current_user = cs.getpeername()
    print('incoming connection from {}'.format(current_user))
    mylock.acquire()
    clientsList.append(current_user)
    client_count += 1
    socketsArray.append(cs)
    message = ''
    for client in clientsList:
        message += str(client) + '\n'
    mylock.release()
    for client in socketsArray:
        tcp_send_string(client, message)

if __name__ == '__main__':
    print('Waiting for incoming connections...')
    try:
        rs = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        rs.bind(('0.0.0.0', 7000))
        rs.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        rs.listen(5)
    except socket.error as msg:
        print(msg.strerror)
        exit(-1)
    while True:
        client_socket, addrc = rs.accept()
        print(addrc)
        t = threading.Thread(target=worker, args=(client_socket,))
        threads.append(t)
        client_count += 1
        t.start()