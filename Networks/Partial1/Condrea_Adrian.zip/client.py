import socket
import sys
import select
import struct
import threading

def tcp_client_init(ip_address, port):
    #create the client socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((ip_address, port))
    return sock

def udp_server_init(ip_address, port):
    sock = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
    sock.bind((ip_address, port))
    return sock


def udp_client_init():
    sock = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
    sock.bind(('0.0.0.0', 1234))
    return sock


def tcp_recv_string(sock):
    string = sock.recv(1024).decode('ascii')
    return string

def tcp_recv_int(sock):
    number = struct.unpack('!i', sock.recv(4))[0]
    return number


def udp_send_string(sock, string, destionation_address):
    sock.sendto(string.encode('ascii'), destionation_address)


def udp_receive_string(sock):
    string, address = sock.recvfrom(1024)
    string = string.decode('ascii')
    return (string, address)


def write_message(client_server, client_udp, clients):
    message = input('message: ')
    if message == "QUIT":
        client_server.close()
        client_udp.close()
    else:
        for client in clients:
            udp_send_string(client_udp, message, client)

def read_message(client_udp):
    while True:
        message = udp_receive_string(client_udp)
        print(message)

if __name__ == '__main__':
    client_server = tcp_client_init('0.0.0.0', 7000)
    client_udp = udp_client_init()
    while True:
        clients = tcp_recv_string(client_server)
        print(clients)
        '''
        clients = clients.split('\n')
        for c in clients:
            c = eval(c)
        #thread for writing in chat
        write_message_thread = threading.Thread(target=write_message, args=(client_server, client_udp, clients))
        write_message_thread.start()

        #thread for getting chat messages
        read_message_thread = threading.Thread(target=read_message, args=(client_udp,))
        read_message.start()
        '''
       



    