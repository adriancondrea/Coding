package Model.Value;

public class FalseValue extends BooleanValue{
    public FalseValue(){
        this.value = false;
    }
}
