package Model.Value;

public class TrueValue extends BooleanValue{
    public TrueValue(){
        this.value = true;
    }
}
