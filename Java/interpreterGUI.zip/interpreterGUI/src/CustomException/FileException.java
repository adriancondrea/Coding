package CustomException;

public class FileException extends CustomException{
    public FileException(String message) { super(message);}
}
