package CustomException;

public class ExpressionException extends CustomException{
    public ExpressionException(String errorMessage) { super(errorMessage);}
}
