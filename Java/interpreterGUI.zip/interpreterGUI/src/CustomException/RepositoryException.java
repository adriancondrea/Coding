package CustomException;

public class RepositoryException extends CustomException{
    public RepositoryException(String errorMessage) { super(errorMessage); }
}
