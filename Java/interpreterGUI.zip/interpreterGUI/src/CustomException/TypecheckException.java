package CustomException;

public class TypecheckException extends CustomException{
    public TypecheckException(String errorMessage){
        super(errorMessage);
    }
}
